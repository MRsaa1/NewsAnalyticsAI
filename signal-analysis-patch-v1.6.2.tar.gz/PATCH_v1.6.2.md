# 🔄 Патч обновления v1.6.2

> **Обновление для уже развернутого проекта Signal Analysis**

---

## 📋 Что изменилось (13 ноября 2025):

### 1. ✅ Дата публикации в карточках новостей
Теперь каждая новость показывает дату и время публикации (золотым цветом)

### 2. ✅ Фильтр по диапазону дат
Добавлено поле "Date To" для выбора диапазона (Date From → Date To)

### 3. ✅ Исправлен DeepSeek API URL
Исправлена ошибка 500 при нажатии кнопки "Анализ"

### 4. ✅ Умный анализ
LLM теперь получает дату публикации и URL статьи для более релевантного анализа

### 5. ✅ Disclaimer со ссылкой
Внизу каждого анализа добавлена ссылка на оригинальный источник

### 6. ✅ Удалена кнопка Telegram Digest
Убрана неиспользуемая кнопка

---

## 🔧 Инструкция по применению патча

### Шаг 1: Подключиться к серверу

```bash
ssh your-user@YOUR_SERVER_IP
```

### Шаг 2: Остановить приложение

```bash
sudo supervisorctl stop signal-analysis
```

### Шаг 3: Сделать backup текущей версии

```bash
cd /home/signalapp/signal-analysis
cp app.py app.py.backup_before_v1.6.2
cp signals.db signals.db.backup_before_v1.6.2
```

### Шаг 4: Загрузить новый app.py

**С локальной машины** (выполнить на вашем компьютере):

```bash
cd ~/signal-analysis
scp app.py your-user@YOUR_SERVER_IP:/home/signalapp/signal-analysis/
```

### Шаг 5: Проверить что файл загружен

**На сервере**:

```bash
ls -lh /home/signalapp/signal-analysis/app.py
# Должен быть обновлен (новая дата)
```

### Шаг 6: Запустить приложение

```bash
sudo supervisorctl start signal-analysis
```

### Шаг 7: Проверить что всё работает

```bash
# Проверить статус
sudo supervisorctl status signal-analysis

# Должно быть: RUNNING

# Проверить логи
sudo supervisorctl tail -f signal-analysis

# Проверить в браузере
curl https://YOUR_DOMAIN.com/health
```

### Шаг 8: Проверить функционал

Откройте в браузере: **https://YOUR_DOMAIN.com/dashboard**

Проверьте:
- ✅ Дата публикации показывается у каждой новости
- ✅ Фильтр "Date To" появился
- ✅ Кнопка "Анализ" работает без ошибки 500
- ✅ Нет кнопки "Telegram Digest"

---

## 🔄 Откат (если что-то пошло не так)

```bash
# Остановить
sudo supervisorctl stop signal-analysis

# Вернуть старую версию
cd /home/signalapp/signal-analysis
cp app.py.backup_before_v1.6.2 app.py

# Запустить
sudo supervisorctl start signal-analysis
```

---

## ⏱️ Время применения патча

**5-10 минут** (остановка → загрузка → запуск → проверка)

---

## 📊 Технические детали

### Измененный файл:

- `app.py` (только этот файл!)

### Изменения в коде:

**Строка 464**: Исправлен DeepSeek URL
```python
DEEPSEEK_URL = "https://api.deepseek.com/v1/chat/completions"  # Добавлен /v1/
```

**Строка 1325-1330**: Добавлен фильтр Date To
```html
<input id="date_to" type="date">
```

**Строка 1457-1464**: Форматирование даты публикации
```javascript
const publishDate = signal.ts_published ? new Date(...)
```

**Строка 1472**: Дата в карточке
```html
<span class="meta-item" style="color: #FFD700;">📅 ${publishDate}</span>
```

**Строка 1335**: Удалена кнопка Telegram
```html
<!-- Удалено: <button>TELEGRAM DIGEST</button> -->
```

**Строка 1552-1554**: Disclaimer внизу анализа
```html
ℹ️ Note: ... refer to original source
```

**Строка 2175-2215**: URL и дата в промпт для LLM
```python
Source URL: {url}
Publication Date: {date}
```

**Строка 2224, 2242**: Инструкция учитывать дату
```
IMPORTANT: Pay attention to the Publication Date
```

---

## ✅ После применения патча

Версия проекта: **1.6.2**  
Дата обновления: **13 ноября 2025**  
Статус: **Обновлено**

---

**Время простоя**: ~1 минута (только перезапуск приложения)

